package frc.robot.commands;

import edu.wpi.first.wpilibj2.command.CommandBase;

import frc.robot.subsystems.LimelightSubsystem;

public class PipelineSwitch extends CommandBase{
    private final LimelightSubsystem limelightSubsystem;
    private final int mode; 
    private final int limelight;
    //0 = high, 1 = low

    
    public PipelineSwitch(LimelightSubsystem limelightSubsystem) {
        this.limelightSubsystem = limelightSubsystem;
        this.mode = 10;
        this.limelight = 0;

        addRequirements(limelightSubsystem);
    }

    public PipelineSwitch(LimelightSubsystem limelightSubsystem, int mode, int limelight) {
        this.limelightSubsystem = limelightSubsystem;
        this.mode = mode;
        this.limelight = limelight;

        addRequirements(limelightSubsystem);
    }


    @Override
    public void initialize() {
        int temp2 = mode;
        if (mode > 9) {
            int temp = (int)limelightSubsystem.getPipeline();
            if (temp == 1) {
                temp2 = 0;
            } else {
                temp2 = 1;
            }
        }

        switch (limelight) {
            case 0:
                limelightSubsystem.setPipeline(temp2);
            case 1:
                limelightSubsystem.setPipelineLow(mode);   
            default:
                limelightSubsystem.setPipeline(temp2);
        }
        
    }

    @Override
    public void execute() {
        

    
    }

    @Override
    public void end(boolean interrupted) {
        
    }

    @Override
    public boolean isFinished() {
        return true;
    }



}
