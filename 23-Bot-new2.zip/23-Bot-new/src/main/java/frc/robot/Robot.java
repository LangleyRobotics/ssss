// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot;

import java.nio.channels.Pipe;

import edu.wpi.first.wpilibj.TimedRobot;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.CommandScheduler;
import edu.wpi.first.wpilibj2.command.Commands;
import edu.wpi.first.wpilibj2.command.InstantCommand;
import frc.robot.commands.PipelineSwitch;
import frc.robot.subsystems.LimelightSubsystem;



public class Robot extends TimedRobot {
  private Command m_autonomousCommand;
  private Command lightsCommand;

  private RobotContainer m_robotContainer;
  private LimelightSubsystem m_limelightSubsystem;

  @Override
  public void robotInit() {
    m_robotContainer = new RobotContainer();
    m_limelightSubsystem = new LimelightSubsystem();

  }

  @Override
  public void robotPeriodic() {
    CommandScheduler.getInstance().run();
  }

  /** This function is called once each time the robot enters Disabled mode. */
  @Override
  public void disabledInit() {}

  @Override
  public void disabledPeriodic() {}

  /** This autonomous runs the autonomous command selected by your {@link RobotContainer} class. */
  @Override
  public void autonomousInit() {

    m_autonomousCommand = m_robotContainer.getAutonomousCommand();


    // schedule the autonomous command (example)
    if (m_autonomousCommand != null) {
      m_autonomousCommand.schedule();
    }

  }

  /** This function is called periodically during autonomous. */
  @Override
  public void autonomousPeriodic() {}

  @Override
  public void teleopInit() {
    // This makes sure that the autonomous stops running when
    // teleop starts running. If you want the autonomous to
    // continue until interrupted by another command, remove
    // this line or comment it out.
   /* *
    lightsCommand = m_robotContainer.getLightsCommand();
    if (lightsCommand != null) {
      lightsCommand.schedule();
    }
    */
    
    if (m_autonomousCommand != null) {
      m_autonomousCommand.cancel();
    }

    //PipelineSwitch coneSwitch = new PipelineSwitch(m_limelightSubsystem, 1);
    PipelineSwitch exposurePipeline = new PipelineSwitch(m_limelightSubsystem, 3, 1);
    //coneSwitch.schedule();
    exposurePipeline.schedule();
  }

  /** This function is called periodically during operator control. */
  @Override
  public void teleopPeriodic() {}

  @Override
  public void testInit() {
    // Cancels all running commands at the start of test mode.
    CommandScheduler.getInstance().cancelAll();
  }

  @Override
  public void testPeriodic() {

  }
}
